# User settings
API_ID =
API_HASH =
PHONE_NUMBER =

# Notifications(unnecessary)
BOT_TOKEN =
CHAT_ID = 

# Buy criteria (put 0 for no limit)
NFT_GIFTS_ONLY = True

GIFT_MIN_PRICE = 100
GIFT_MAX_PRICE = 5000
MAX_GIFT_SUPPLY = 200000
QUANTITY = 0
RECEPIENT(channel/user) = @user

# Multiple gifts(buys all available gifts that meet the criteria with priority to lower supply)
BUY_MULTIPLE_GIFTS = True

# Hide senders name
HIDE_SENDER_NAME = True

